// function calc() {
//     for (let i = 2520; i < 1000000000; i += 2520) { 
//         for (let j = 10; j <= 20; j++) {
//             if (i % j !== 0) {
//                 break;
//             }
//             if (j === 20 && i % j === 0) {
//                 console.log(i);
//             }
//         }   
//     } 
// }
// calc()

let k = 48; 
let arrAll = [];
function primeFactors(k){
    let arr = [];
    for (let i = 2; i <= k;){
        if(Number.isInteger(k / i)){
            arr.push(i);
            k = k / i;
        }
        else{
            i++;
        }
    }
    arrAll.push(arr);
}

for (let n = 11; n <= 20; n++){
    primeFactors(n);
}
console.log(arrAll)


let numArr = [];
for(let count = 0; count < arrAll.length - 1; count++){
    console.log(arrAll[count]);
    for(let i = 0; i < arrAll[count].length; i++){
        console.log(arrAll[count][i]);
        if(arrAll[count][i] == arrAll[count + 1][i]){
            numArr.push(arrAll[count][i]);
        }
    }
}