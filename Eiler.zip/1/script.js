let answers = document.querySelector('#answers');
let p = document.createElement('p');

//1 задача

let k = 0;
for (let i = 0; i < 1000; i++){
    if(i % 3 == 0 || i % 5 == 0)
    {
        k += i;
        console.log(i);
    }
}
p.textContent = k;
answers.appendChild(p);
console.log(k);
