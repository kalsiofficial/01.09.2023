// 4 задача

isPalindrom = function(a){
    let b = String(a).split('').reverse().join('');
    if (a==b)
        return true;
}

findPalindrom = function() {
    let k = 0; 
    let sum;
    for (let i = 999; i >= 900; i--){
        for(let j = 999; j >= 900; j--){
            // console.log(i,j);
            sum = i*j;
            if (isPalindrom(sum))
                if(sum>k)
                    k=sum;
        }
    }
    return k;
}
console.log(findPalindrom())