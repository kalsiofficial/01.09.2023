//2 задача

// let arr = [1, 2];
// let k = 0;

// function arrFin() {
//     for (let i = 1;  arr[i] < 8000000; i++){
//         arr.push(arr[arr.length - 1] +  arr[arr.length - 2]);
//         if (arr[i] % 2 == 0 && arr[i] < 8000000)
//         {
//             k += arr[i];
//         }
//         else if (arr[i] > 8000000) {
//             break;
//         }
//     }
// }
// console.time('arr1');
// arrFin();
// console.timeEnd('arr1');
// p.textContent = k;
// answers.appendChild(p);
// console.log(k);


//2задача

// let k = 0, fib = 0, pre = 1, prePre = 0;

// function arrFin(){
//     for (fib = 0; fib < 4000000;) {
//         fib = pre + prePre;
//         if (fib % 2 == 0)
//             k += fib;
//         else if(fib > 4000000) {
//             break;
//         }
//         prePre = pre;
//         pre = fib;
//     }
//     console.log('Сумма четных элементов: ' + k);
// }


// console.time('arr1');
// arrFin()
// console.timeEnd('arr1');


//3 задача

let start = performance.now();

let supNum = 600851475143;
let num = Math.round(Math.sqrt(supNum));
// console.log(num);
let del;
for (let i = 3; i < num; i++) {
    if(supNum % i == 0){
        let isSimple = true;
        for (let j = 2; j < i; j++){
            if (i % j == 0){
                isSimple = false;
                break;
            }
        }
        if (isSimple) {
            del = i;
            console.log(del);
        } 
    }
}

let end = performance.now();
console.log(end - start + 'ms');