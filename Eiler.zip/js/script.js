let answers = document.querySelector('#answers');
let p = document.createElement('p');

//1 задача
/*
let k = 0;
for (let i = 0; i < 1000; i++){
    if(i % 3 == 0 || i % 5 == 0)
    {
        k += i;
        console.log(i);
    }
}
p.textContent = k;
answers.appendChild(p);
console.log(k);
*/

//2 задача

/*
let arr = [1, 2];
let k = 0;

for (let i = 1;  arr[i] < 4000000; i++){
    arr.push(arr[arr.length - 1] +  arr[arr.length - 2]);
    if (arr[i] % 2 == 0 && arr[i] < 4000000)
    {
        k += arr[i];
    }
}

console.log(arr);
p.textContent = k;
answers.appendChild(p);
console.log(k);
*/

//3 задача

// let num = 600851475143;


// for (let i = 0; i < 600851475143/2 ; i++) {
//     if (num % i == 0)
//     {
//         let k = i;
//         console.log(k)
//     }
// }