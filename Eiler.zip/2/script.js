//2 задача

// let arr = [1, 2];
// let k = 0;

// function arrFin() {
//     for (let i = 1;  arr[i] < 8000000; i++){
//         arr.push(arr[arr.length - 1] +  arr[arr.length - 2]);
//         if (arr[i] % 2 == 0 && arr[i] < 8000000)
//         {
//             k += arr[i];
//         }
//         else if (arr[i] > 8000000) {
//             break;
//         }
//     }
// }
// console.time('arr1');
// arrFin();
// console.timeEnd('arr1');
// p.textContent = k;
// answers.appendChild(p);
// console.log(k);


//2задача

// let k = 0, fib = 0, pre = 1, prePre = 0;

// function arrFin(){
//     for (fib = 0; fib < 4000000;) {
//         fib = pre + prePre;
//         if (fib % 2 == 0)
//             k += fib;
//         else if(fib > 4000000) {
//             break;
//         }
//         prePre = pre;
//         pre = fib;
//     }
//     console.log('Сумма четных элементов: ' + k);
// }


