// console.time('arr1');
// arrFin()
// console.timeEnd('arr1');


//3 задача

let start = performance.now();

let supNum = 600851475143;
let num = Math.round(Math.sqrt(supNum));
// console.log(num);
let del;
for (let i = 3; i < num; i++) {
    if(supNum % i == 0){
        let isSimple = true;
        for (let j = 2; j < i; j++){
            if (i % j == 0){
                isSimple = false;
                break;
            }
        }
        if (isSimple) {
            del = i;
            console.log(del);
        } 
    }
}

let end = performance.now();
console.log(end - start + 'ms');