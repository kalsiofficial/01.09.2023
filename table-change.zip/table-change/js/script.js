const reverse = () => {
    document.querySelector('tbody').classList.toggle('tbodyRev');
    let trs = document.querySelectorAll('tr');
    trs.forEach(tr => {
        tr.classList.toggle('trRev')
    })
}