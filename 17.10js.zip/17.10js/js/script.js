
const myName = 'Katya';
const mySurname = 'Zolotareva';
const numberOfG = 9.8;
let isValid = true;
let isObject = console;
let isMethod = console.log;
let isFunction = function(){
    let word ='Слово'
    return word
};
let isSymbol = Symbol();
let emptyVar = null;
let unusedVar;

let types = [
    'myName: '+typeof myName,
    'numberOfG :'+typeof numberOfG,
    'isValid: '+typeof isValid,
    'isObject: '+typeof isObject,
    'isFunction: '+typeof isFunction,
    'isSymbol: '+typeof isSymbol,
    'emptyVar: '+typeof emptyVar,
    'unusedVar: '+typeof unusedVar
]

myFunction = function(){
    for (let i = 0; i<types.length; i++) {
        let p = document.createElement('p');
        p.innerHTML = types[i];
        document.body.append(p);
    }
}

// console.log(isObject)
// alert("asdfwe")