const spoilers = document.querySelectorAll('.spoiler');
console.log(spoilers);

spoilers.forEach(spoiler =>
    {
        const content = spoiler.querySelector('.spoiler-content');
        const toggle = spoiler.querySelector('.spoiler-toggle');
        toggle.innerText = '+';

        toggle.addEventListener('click', () => {
            content.classList.toggle('show');
            if(content.classList.contains('show')) {
                toggle.innerText = '-';
            }
            else{
                toggle.innerText = '+';
            }
        })
    })


// spoilers.forEach(spoiler =>
//     {
//         const content = document.querySelector('.spoiler-content');
//         const toggle = document.querySelector('.spoiler-toggle');

//         toggle.addEventListener('click', () => {
//             const isExpanded = toggle.innerText === '-';
//             if(isExpanded) {
//                 toggle.innerText = '+';
//                 content.style.display = 'none'
//             }
//             else {
//                 toggle.innerText = '-';
//                 content.style.display = 'block'
//             }
//         })
//     })
