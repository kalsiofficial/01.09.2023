let input = document.getElementById('inputFilter')
let buttonFilter = document.getElementById('btnFilter')
let textFilter = document.getElementById('numberFilter')

buttonFilter.addEventListener('click', function() {
	let numbers = '';
	let inputValue = input.value;

	for (i = 0; i <= inputValue.length; i++) {
		if (!isNaN(Number(inputValue[i]))) {
			numbers += inputValue[i];
		}
	}
	textFilter.innerHTML = numbers;
})

