// let password = document.querySelectorAll('#pass, #secPass');
// console.log(password);

// password.forEach(elem => {
//     elem.addEventListener('input', function() {
//         console.log(password[0].value)
//         if(password[0].value != password[1].value) {
//             document.querySelector('p').textContent = 'Пароли не совпадают'
//         }
//         else{
//             document.querySelector('p').textContent = ''
//         }
//     })
// })

const form = document.querySelector('#reg');
const passwords = form.querySelectorAll('input[type = "password"]');
const btn = form.querySelector('#btn');
let inputs = form.querySelectorAll("input");
let message = document.querySelectorAll('p');
console.log(passwords);

form.addEventListener('input', () => {
    let i = 0;
    inputs.forEach(input => {
        if(!input.value){
            btn.disabled = true;
            message[0].textContent = 'Заполните все поля';
        }
        else {
            i++;
        }
    })
    if(i == inputs.length) {
        message[0].textContent = '';
    }
    if(i == inputs.length && checkPass()){
        btn.disabled = false;
        message[1].textContent = '';
    }
    console.log(i, inputs.length);
})

checkPass = () => {
    if(passwords[0].value != passwords[1].value) {
        btn.disabled = true;
        message[1].textContent = 'Пароли не совпадают';
        message[1].style.color = 'red';
        return false;
    }
    else{
        btn.disabled = false;
        return true;
    }
}

// passwords.forEach(password => {
//     password.addEventListener('input', () => {
//         if (passwords[0].value != passwords[1].value) {
//             form.querySelector('#pass').textContent = 'Пароли не совпадают';
//             btn.disabled = 'disabled';
//         }
//         else{
//             form.querySelector('#pass').textContent = '';
//             btn.disabled = '';
//         }
//     })
// })


// console.log(inputs);


// inputs.forEach(inp => {
//     this.addEventListener('input', () => {
//         if(inputs[i] != '' ){
//             console.log(inp + inputs.length - 1)
//             form.querySelector('#all').textContent = '';
//             btn.disabled = '';
//         }
//         else{
//             form.querySelector('#all').textContent = 'Заполните все поля';
//             btn.disabled = 'disabled';
//         }
//     })
// })
