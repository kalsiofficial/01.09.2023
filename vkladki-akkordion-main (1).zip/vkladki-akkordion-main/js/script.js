let parent = document.querySelector('#parent');
let links  = parent.querySelectorAll('.tab .link a');
let tab   = parent.querySelectorAll('.tab ');

console.log(links)

links.forEach(link => {
    link.addEventListener('click', function(e) {
        let activeTab = parent.querySelector('.tab.active');
        let newTab = link.closest('.tab');
        if(newTab !== activeTab){
            newTab.classList.add('active');
        }
        if(activeTab){
            activeTab.classList.remove('active');
        }
    });
})
