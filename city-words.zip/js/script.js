let message = document.querySelector('#message');
let buttonCity = document.querySelector('#button');
let cities = [];
let field = document.querySelector('#field');
let p = document.createElement('p');

function clear() {
    field.value = ''
}

function cityOne() {
    for(let i = 0; i < cities.length; i++) 
    {
        if (field.value.toLowerCase() == cities[i].toLowerCase())
        {   
            return false;
        }

    }
}

function check() {
    if ( (cities.length === 0) || (cities[cities.length-1][cities[cities.length - 1].length - 1] == field.value[0].toLowerCase() && cityOne() != false) ) 
    {
        
        cities.push(field.value);
        p.textContent = field.value;
        message.appendChild(p);
        console.log(cities);
    }

    else if (cities[cities.length-1][cities[cities.length - 1].length - 1] != field.value[0].toLowerCase())
    {
        alert ('Буквы не совпадают');
    }

    else if (cityOne() == false)
    {
        alert('Такой город уже был');
    }
}

buttonCity.addEventListener('click', function(){
    check();

    clear();
})