let bgcolors = ['red', 'green', 'blue', 'pink', 'yellow'];
// let bordercolors = ['border-red', 'border-blue', 'border-green', 'border-pink'];

document.querySelector('#set').addEventListener('click', function () {
	isWin = function() {
		let tdList= document.querySelectorAll('td');
		for(let i = 0; i < tdList.length-1; i++) {
			if (tdList[i].style.background != tdList[i + 1].style.background) 
			{
				console.log(tdList[i].style.background, tdList[i + 1].style.background);
				return false;
			}
		}
		return true;
	};

	let rows = document.querySelector('#rows').value;
	let cols = document.querySelector('#cols').value;
	let nameOne = document.querySelector('#name1').value;
	let nameTwo = document.querySelector('#name2').value;
	let k=1;
	let names = [nameOne, nameTwo];
	let playersName = document.querySelector('#players');

	nameChange = function(){
		playersName.style.color = pColor[k%2];
		playersName.textContent = names[k%2];
		k++;
	}

	let table = document.querySelector('#field');
	function random(min, max) {
		return Math.floor(Math.random() * (max - min + 1)) + min;
	}
	//const randomClass = bgcolors[random];
	let pColor = [bgcolors[random(0, bgcolors.length - 1)], bgcolors[random(0, bgcolors.length - 1)]];
	console.log(pColor);
	for (let tr of document.querySelectorAll('tr')){
		tr.remove();
	}
    
	for (let i = 1; i <= rows; i++){
		let tr = document.createElement('tr')
		for(let i = 1; i <= cols; i++) {
			let td = document.createElement('td');
			playersName.textContent = names[0];
			playersName.style.color = pColor[0]
			setTimeout(function() {
				tr.appendChild(td).style.background = bgcolors[random(0, bgcolors.length - 1)];
			}, i*100)
			
			setTimeout(function(){
				table.appendChild(tr);
			}, i*100)

			td.addEventListener('click', function(){
				nameChange();
				if(bgcolors.indexOf(this.style.background) == bgcolors.length - 1)
					this.style.background = bgcolors[0];
				else
					this.style.background = bgcolors[bgcolors.indexOf(this.style.background) + 1];

				if(isWin()) 
					alert('Игрок '+ names[k%2] + ' победил!!!!!!');
			});
		}
	}
	

// 	let tabTr = document.querySelectorAll('tr');
// 	for (let elem of tabTr) {
// 		for (let i = 1; i <= cols; i++){
// 			let random = Math.floor(Math.random() * bgcolors.length);
// 			let randomBorder = Math.floor(Math.random() * bordercolors.length);
// 			const randomClass = bgcolors[random];
// 			const randomBorderClass = bordercolors[randomBorder];
// 			elem.appendChild(document.createElement('td'))
// 		}
// 	}

	
})

//смена цвета

// document.querySelector('table').addEventListener('click', function (event) {
// 	let target = event.target;
// 	if (target.tagName.toLowerCase() === 'td')
// 	// console.log(bordercolors.indexOf(target.classList[0]))
// 		if ((bgcolors.indexOf(target.classList[0]) + 1) < bgcolors.length) {
// 			target.className = bgcolors[bgcolors.indexOf(target.classList[0]) + 1];
// 		}
// 		else 
// 			target.className = bgcolors[0];
// 		// if ((bordercolors.indexOf(target.classList[0]) + 1) < bordercolors.length) {
// 		// 	target.className = bordercolors[bordercolors.indexOf(target.classList[0]) + 1];
// 		// }
// 		// else 
// 		// 	target.className = bordercolors[0];
// })




document.querySelector('#del').addEventListener('click', function () {
	let tabTr = document.querySelectorAll('tr');
	for (let tr of tabTr){
		tr.remove();
	}
})

document.querySelector('#delRows').addEventListener('click', function () {
	let table = document.getElementById('field');
	let tabTrCount = document.querySelectorAll('tr').length;
	if (tabTrCount >= 1)
		{
			table.deleteRow(tabTrCount - 1);
		}
	else
	{
		alert('Нет строк для удаления');
	}
	// let tabTr = document.querySelectorAll('tr');
	// table.deleteRow(tabTr - 1)
})

// document.querySelector('#delCols').addEventListener('click', function () {})